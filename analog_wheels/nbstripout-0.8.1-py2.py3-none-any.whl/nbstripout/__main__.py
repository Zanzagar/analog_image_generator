from nbstripout import main

main()
